/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sync.Antic.entity;

/**
 *
 * @author berna
 */
public enum Status {
    EN_COURS,
    VALIDE,
    ARCHIVE
}
